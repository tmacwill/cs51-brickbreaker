#!/bin/sh
java -cp ".:*" brickBreaker/Start